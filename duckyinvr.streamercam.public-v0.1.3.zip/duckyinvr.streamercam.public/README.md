# Streamer Cam Public Beta v0.1.3

A reduced public-test build of DuckyinVR Streamer Cam. This package is intentionally smaller than the private/personal build.

## Included modes

Outside arena:

- Third Person - Head Movement
- Free Cam

Inside arena:

- Basic Ball Follow
- Third Person - Head Movement
- Third Person - Ball Look

## Included graphics

- Ball trail only
- Ball trail style, fade, thickness, glow/core width, vibrance, draw lifetime, and speed-color controls

## Included goal explosions

- Basic Burst
- Ripple Wave
- Claw Strike
- Implosion

## Not included in the public UI

Duckling pet, Vlog/Follow+, fixed camera, cinematic/sideline/full-auto autocast, target/team markers, ball outline, and experimental camera-look/postprocess controls are intentionally hidden from this public beta.

## Install / test

Install the `duckyinvr.streamercam.public/` package folder from the zip. It uses package name `duckyinvr.streamercam.public` so it can be tested alongside the private Streamer Cam package.

If you later want this to replace the main public package identity, change `package.json.name` back to `duckyinvr.streamercam` before release.

## v0.1.1

Fixes the GUI not rendering in Orion due to escaped quote characters in the generated public `onGui()` block.

## v0.1.2

Adds defensive `pcall` wrappers around GUI sections and a visible top-level UI heartbeat so one bad widget cannot blank the whole settings panel.

## v0.1.3

Bundles `particlesystem.luau` in the zip. The previous public zip omitted this required module, so Orion could fail to load the package and the F3 menu would appear blank.
